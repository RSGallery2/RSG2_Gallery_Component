# Javascript Carousel
An implemenation for jank free animate carousel with pure javascript (ES6)
---

## Instructions
- Clone this repo
- In your terminal `sudo npm -g install http-server`
- `cd` into project directory ,then run `http-server`
- Visit ip adress appear on the console

---

Screen shot(gif):

![carousel-animate](https://user-images.githubusercontent.com/6436298/37321790-8683e558-26ac-11e8-9130-d8d82d063912.gif)
