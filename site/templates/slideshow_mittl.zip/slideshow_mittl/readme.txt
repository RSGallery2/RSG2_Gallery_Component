https://github.com/nonusae/js-carousel/blob/master/index.html

https://github.com/nonusae/js-carousel

https://codepen.io/thunderella42/pen/YvMyEY



Gave up

why background-image: URL .... instead of 
<a>
	<img ....>
</a>
